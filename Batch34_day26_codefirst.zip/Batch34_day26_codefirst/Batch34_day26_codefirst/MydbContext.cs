﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace Batch34_day26_codefirst
{
    class MydbContext:DbContext
    {
        public MydbContext():base("Codefirst1_Oct19")
        {

        }
        //all the tables /entities will be put into DBSet
        public virtual DbSet<Programme> Programmes { get; set; }
        public virtual DbSet<StudentAddress> StudentAddresses { get; set; }
        public virtual DbSet<Student> Students { get; set; }
        public virtual DbSet<Subject> Subjects { get; set; }
    }
}
