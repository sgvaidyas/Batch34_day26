﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch34_day26_codefirst
{
    class Program
    {
        static void Main(string[] args)
        {
            MydbContext db = new MydbContext();
            try
            {
                Programme p = new Programme();
                p.Title = "MCA";
                p.Duration = 2;
                p.fees = 500000;
                db.Programmes.Add(p);
                db.SaveChanges();
                Console.WriteLine("Db created");

            }
            catch(Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
        }
    }
}
