﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch34_day26_codefirst
{
    class Programme
    {
        //Scalar prop
        public int Id { get; set; }//Primary key
        public string Title { get; set; }
        public int Duration { get; set; }
        public float fees { get; set; }

        //Navigational prop
        //1 Program can have many students
        public virtual ICollection<Student> Students { get; set; }

        //1 programme -> multiple subjects
        public virtual ICollection<Subject> Subjects { get; set; }
    }
}
