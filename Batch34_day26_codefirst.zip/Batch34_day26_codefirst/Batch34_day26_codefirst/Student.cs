﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch34_day26_codefirst
{
    class Student
    {
        //Scalar Properties
        public int StudentId { get; set; }//Primary key
        public string Name { get; set; }
        public DateTime BirthDate { get; set; }
        public long Phone { get; set; }

        //Navigational
        //each student belongs to 1 Program
        public virtual Programme Programme { get; set; }
        //each student has 1 address
        //this is commented due to deadlock situation of dependencies
        // between student and address
        //public virtual StudentAddress StudentAddress { get; set; }
    }
}
