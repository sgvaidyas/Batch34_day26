﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch34_day26_codefirst
{
    class StudentAddress
    {
        //Scalar prop
        public int Id { get; set; }//Prim key
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int Zipcode { get; set; }

        //navigational
        //each address related to 1 student
       // public virtual Student Student { get; set; }
    }
}
