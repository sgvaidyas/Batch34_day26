﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch34_day26_codefirst
{
    class Subject
    {
        //Scalar
        public int SubjectId { get; set; }//Prim
        public string Name { get; set; }
        public int Marks { get; set; }

        //Navigational
        //each subject belongs to 1 prog
        public virtual Programme Programme { get; set; }
    }
}
